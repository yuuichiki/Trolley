﻿using System.Windows.Controls;

namespace RCabinet.Views
{
    /// <summary>
    /// Interaction logic for ManageAppSettings.xaml
    /// </summary>
    public partial class ManageAppSettings : UserControl
    {
        public ManageAppSettings()
        {
            InitializeComponent();
        }
    }
}
