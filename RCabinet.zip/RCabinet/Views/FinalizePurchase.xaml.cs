﻿using RCabinet.Interfaces;
using RCabinet.Models;
using RCabinet.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace RCabinet.Views
{
    /// <summary>
    /// Interaction logic for FinalizePurchase.xaml
    /// </summary>
    public partial class FinalizePurchase : UserControl
    {
        public FinalizePurchase()
        {
            InitializeComponent();
        }
    }
}
