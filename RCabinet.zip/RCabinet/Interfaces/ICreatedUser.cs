﻿using RCabinet.Models;

namespace RCabinet.Interfaces
{
    interface ICreatedUser
    {
        void CreatedUser(User user);
    }
}
