﻿using RCabinet.Models;

namespace RCabinet.Interfaces
{
    interface IFinishedPurchase
    {
        void FinishedPurchase(Purchase purchase);
    }
}
